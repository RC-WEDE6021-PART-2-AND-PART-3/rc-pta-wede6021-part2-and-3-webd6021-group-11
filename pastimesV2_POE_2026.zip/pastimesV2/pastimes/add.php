<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="" method="post">
    <p>Name: <input type="text" name="name"></p><p>Email: <input type= "text" name="email"></p>
    <p>Password: <input type="password" name="pass"></p>
    <p> <input type="submit" value="add" name="add"></p>
    </form>
</body>
</html>
<?php
include "db.php"; if(isset($_POST['add'])){
$name =$_POST['name'];$email =$_POST['email'];$password=md5($_POST['pass']);
$sql ="INSERT INTO users(name,email,password)
VALUES('$name','$email','password')";
if(mysqli_query($link,sql)){
    echo "User added <a href='index.php>view updatedS