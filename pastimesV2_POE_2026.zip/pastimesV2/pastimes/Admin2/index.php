<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body> <h1>List of User</h1>h1> <a href="add.php">Add User</a>
    <table border>
        <tr><th>ID</th>TH>Name</th></th>Email</th><th>Passowrd</th>
        <th>Action</th></tr>
        <?php
        $results = msqli_query($link,"SELECT * FROM users");
        if(msqli_num_rows($results)>0){ 
            while($row=mysqli_fetch_assoc($results)){?>
         </tr>
            <td><?php echo $row['id']; ?> </td><td><?php echo $row['name']; ?> </td>
            <td><?php echo $row['email']; ?> </td><td></td><?php echo $row['passowrd']; ?> </td>
            <td>
                <a href="delete.php?id=<?php echo '$row[id];'?>" onclick="return confirm('are u sure wanna delete?');>
                Delete</a></td>
        </tr>
        <?php  }
        }esle{
            echo "no data";
        }
?>
       </table>
       </body>
       </html>